//
//  ViewController.swift
//  secretNumber
//
//  Created by CIS Student on 9/24/17.
//  Copyright © 2017 Jonathan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBOutlet weak var guessResult: UILabel!
    @IBOutlet weak var numberGuess: UITextField!
    
    @IBAction func guessButton(_ sender: UIButton) {
        let num = Int(numberGuess.text!)!
        let randomNumber = Int(arc4random_uniform(101))
        if (num == randomNumber){
            guessResult.text = String("Correct")
        }
        else if (num > randomNumber){
            guessResult.text = String("Too High")
        }
        else {
            guessResult.text = String("Too Low")
        }
        
    }


}

